import java.sql.SQLException;
import java.util.Scanner;

public interface User extends User1 {

	

	public static void call () throws SQLException {

		User1.user1();
}
}
