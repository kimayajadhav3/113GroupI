import java.sql.SQLException;
import java.util.Scanner;

public interface Admin extends Admin1 {

	public static void method () throws SQLException {

		Scanner sc = new Scanner (System.in);
		
		System.out.println("Enter Username");
		
		String Username = sc.nextLine();
		
		System.out.println("Enter Password");
		
		String Password = sc.nextLine();
		
		
		if(Username.equals(Password)) {
	
			System.out.println("Welcomme Admin");
			System.out.println("************************************************");
			System.out.println("Please Enter Your Choice");
			System.out.println("************************************************");
			System.out.println();
			System.out.println("If you want to see Quantity_of_Products then Press 1");
			System.out.println("If you want to see Register_User then Press 2");
			System.out.println("If you want to see User_History then Press 3");

		int first = sc.nextInt();
		
		if(first ==1) {
			Admin1.admin1();
			System.out.println("If you want to see Register_User then Press 2");
			System.out.println("If you want to see User_History then Press 3");
			int second = sc.nextInt();
			if(second==2) {
				Admin1.admin2();
			}
			if(second==3) {
				Admin1.admin3();
			}
		}
		if(first ==2) {
			Admin1.admin2();
			System.out.println("If you want to see Quantity_of_Products then Press 1");
			System.out.println("If you want to see User_History then Press 3");
			int third = sc.nextInt();
			if(third==1) {
				Admin1.admin1();
			}
			if(third==3) {
				Admin1.admin3();
			}
			
		}
		if(first ==3) {
			Admin1.admin3();
			System.out.println("If you want to see Quantity_of_Products then Press 1");
			System.out.println("If you want to see Register_User then Press 2");
			int fourth = sc.nextInt();
			if(fourth==1) {
				Admin1.admin1();
			}
			if(fourth==2) {
				Admin1.admin2();
			}
		}
		if((first != 1) && (first!=2) && (first!=3)){
			System.out.println("Please Enter Valid Input And Login Again");
			System.out.println("*********************************************");
			System.out.println();
			Admin.method();
			
		}
			
		}
						
		}

	
	}


	