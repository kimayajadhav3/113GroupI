import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public interface User1 {

	public static void user1 () throws  SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/test11march?characterEncoding=utf8";
			String user="root";
			String password="Bhushan#97";		
			Connection con=DriverManager.getConnection(url, user, password);		
			Statement stmt=con.createStatement();
			String query="select user_name from register_users";	
			ResultSet i = stmt.executeQuery(query);
			while (i.next()) {
				String username = i.getString("user_name");
			
			Scanner sc = new Scanner (System.in);
			
			System.out.println("Enter Username");
			
			String Username = sc.nextLine();
			
		if(Username.equals(username)){
			System.out.println("You are Registerd User");
			User1.userchoise();
			System.out.println("You Can Bye Products From Below List");
			Admin1.admin4();
		}else {
			System.out.println("You are not Register_User Please Register Yourself First");
		}
			}
			
					stmt.close();
					con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public static void userchoise() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please Enter the Userame");
		String username = sc.nextLine();
		System.out.println("Please Enter the Password");
		String pass = sc.nextLine();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/test11march?characterEncoding=utf8";
			String user="root";
			String password="Bhushan#97";		
			Connection con=DriverManager.getConnection(url, user, password);		
			String query="insert into register_user values (?,?)";	
			PreparedStatement pst = con.prepareStatement(query);
			 pst.execute();
			pst.setString(1, username);
			pst.setString(2, pass);
					pst.close();
					con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	}
	

