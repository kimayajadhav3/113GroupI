import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public interface Admin1 {

	public static void admin2 () throws  SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/test11march?characterEncoding=utf8";
			String user="root";
			String password="Bhushan#97";		
			Connection con=DriverManager.getConnection(url, user, password);		
			Statement stmt=con.createStatement();
			String query="select user_name from register_users";	
			ResultSet i = stmt.executeQuery(query);
			while (i.next()) {
				String username = i.getString("user_name");
				System.out.println(username);
			}
					stmt.close();
					con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public static void admin1 () throws  SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/test11march?characterEncoding=utf8";
			String user="root";
			String password="Bhushan#97";	
			Connection con=DriverManager.getConnection(url, user, password);	
			Statement stmt=con.createStatement();
			String query="select NAME,QUANTITY from products";	
			ResultSet i = stmt.executeQuery(query);
			while (i.next()) {
				String quantity = i.getString("QUANTITY");
				String name = i.getString("NAME");
				System.out.println(quantity+" "+name);
			}
					stmt.close();
					con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public static void admin3 () throws  SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/test11march?characterEncoding=utf8";
			String user="root";
			String password="Bhushan#97";
			Connection con=DriverManager.getConnection(url, user, password);
			Statement stmt=con.createStatement();
			String query="select User_Name from users";
			ResultSet i = stmt.executeQuery(query);
			while (i.next()) {
				String username = i.getString("User_Name");
				System.out.println(username);
			}
					stmt.close();
					con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public static void admin4 () throws  SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/test11march?characterEncoding=utf8";
			String user="root";
			String password="Bhushan#97";	
			Connection con=DriverManager.getConnection(url, user, password);	
			Statement stmt=con.createStatement();
			String query="select NAME,DESCRIPTION,PRICE from products";	
			ResultSet i = stmt.executeQuery(query);
			while (i.next()) {
				String name = i.getString("NAME");
				String description = i.getString("DESCRIPTION");
				String price = i.getString("PRICE");
				System.out.println(name+" "+description+" "+price);
			}
					stmt.close();
					con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
}
