import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public interface Guest {

	public static void guest1 () throws  SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/test11march?characterEncoding=utf8";
			String user="root";
			String password="Bhushan#97";	
			Connection con=DriverManager.getConnection(url, user, password);	
			Statement stmt=con.createStatement();
			String query="select NAME,PRISE,DESCRIPTION from products";	
			ResultSet i = stmt.executeQuery(query);
			while (i.next()) {
				String prise = i.getString("PRISE");
				String name = i.getString("NAME");
				String description = i.getString("DESCRIPTION");
				System.out.println(name+" "+prise+" "+description);
			}
					stmt.close();
					con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
}
