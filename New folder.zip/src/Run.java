import java.sql.SQLException;
import java.util.Scanner;

public interface Run extends Admin,Guest,User{

	public static void method2 () throws SQLException {
	
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Welcome to E-Commerce Application");
		System.out.println();
		System.out.println("************************************************");
		System.out.println("************************************************");
		System.out.println();
		System.out.println("If Your Admin then please Press 1");
		System.out.println("If Your Guest then please Press 2");
		System.out.println("If Your User then please press 3");
		System.out.println("If You want to register yourself then please press 4");
		
		int no = sc.nextInt();
		if(no==1) {
			Admin.method();
		}
		else if(no==2) {
			Guest.guest1();
		}
		else if(no==3) {
			User.call();
		}
		else if(no==4) {
			User.call();
		}

	}

	
}
